<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>
</head>
<body>

    <h1 class="text-center text-primary mt-5 mb-4">Formulario de usuarios</h1>

    <div class="container  col-md-4">

    <form>
        <div class="mb-3">
            <label for="nombre" class="form-label">Nombre: </label>
            <input type="text" class="form-control" id="nombre" >
        </div>

        <div class="mb-3">
            <label for="Apellido" class="form-label">Apellido: </label>
            <input type="text" class="form-control" id="apellido" >
        </div>                

        <div class="mb-3">
            <label for="correo" class="form-label">Correo: </label>
            <input type="email" class="form-control" id="correo" >
        </div>

        <div class="mb-3">
            <label for="telefono" class="form-label">Telefono: </label>
            <input type="number" class="form-control" id="telefono" >
        </div>

        <button type="submit" class="btn btn-danger "> Guardar Usuario</button>

    </form>
</div>


</body>
</html><?php /**PATH C:\laragon\www\2doP\resources\views/welcome.blade.php ENDPATH**/ ?>